﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PLDT_VirtualQueueSystem
{
    public class Class1
    {
        static DataClasses1DataContext db = null;

       
    }
}
