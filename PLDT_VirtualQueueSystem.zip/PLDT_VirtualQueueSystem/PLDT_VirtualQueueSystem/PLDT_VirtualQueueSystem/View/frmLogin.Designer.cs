﻿namespace PLDT_VirtualQueueSystem
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbRegister = new System.Windows.Forms.LinkLabel();
            this.lbUsername = new System.Windows.Forms.Label();
            this.lbPassword = new System.Windows.Forms.Label();
            this.lbWarning = new System.Windows.Forms.Label();
            this.btnback_default = new System.Windows.Forms.PictureBox();
            this.btnback = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnLogin = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pkeypad = new System.Windows.Forms.Panel();
            this.newline = new System.Windows.Forms.PictureBox();
            this.backspace = new System.Windows.Forms.PictureBox();
            this.p = new System.Windows.Forms.PictureBox();
            this.l = new System.Windows.Forms.PictureBox();
            this.o = new System.Windows.Forms.PictureBox();
            this.k = new System.Windows.Forms.PictureBox();
            this.i = new System.Windows.Forms.PictureBox();
            this.space = new System.Windows.Forms.PictureBox();
            this.dot = new System.Windows.Forms.PictureBox();
            this.m = new System.Windows.Forms.PictureBox();
            this.j = new System.Windows.Forms.PictureBox();
            this.u = new System.Windows.Forms.PictureBox();
            this.n = new System.Windows.Forms.PictureBox();
            this.h = new System.Windows.Forms.PictureBox();
            this.y = new System.Windows.Forms.PictureBox();
            this.b = new System.Windows.Forms.PictureBox();
            this.g = new System.Windows.Forms.PictureBox();
            this.t = new System.Windows.Forms.PictureBox();
            this.v = new System.Windows.Forms.PictureBox();
            this.f = new System.Windows.Forms.PictureBox();
            this.c = new System.Windows.Forms.PictureBox();
            this.d = new System.Windows.Forms.PictureBox();
            this.x = new System.Windows.Forms.PictureBox();
            this.r = new System.Windows.Forms.PictureBox();
            this.s = new System.Windows.Forms.PictureBox();
            this.z = new System.Windows.Forms.PictureBox();
            this._e = new System.Windows.Forms.PictureBox();
            this.a = new System.Windows.Forms.PictureBox();
            this.w = new System.Windows.Forms.PictureBox();
            this.q = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.btnback_default)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            this.pkeypad.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.newline)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backspace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.space)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.h)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._e)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtUsername
            // 
            this.txtUsername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(262, 187);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(280, 26);
            this.txtUsername.TabIndex = 3;
            this.txtUsername.TabStop = false;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            this.txtUsername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyDown);
            this.txtUsername.Leave += new System.EventHandler(this.txtUsername_Leave);
            this.txtUsername.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtUsername.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(262, 245);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(289, 26);
            this.txtPassword.TabIndex = 3;
            this.txtPassword.TabStop = false;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            this.txtPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyDown);
            this.txtPassword.Leave += new System.EventHandler(this.txtPassword_Leave);
            this.txtPassword.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyUp);
            this.txtPassword.Enter += new System.EventHandler(this.txtPassword_Enter);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(159)))), ((int)(((byte)(159)))));
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(432, 313);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "login";
            // 
            // lbRegister
            // 
            this.lbRegister.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbRegister.AutoSize = true;
            this.lbRegister.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRegister.LinkColor = System.Drawing.Color.MediumSeaGreen;
            this.lbRegister.Location = new System.Drawing.Point(263, 297);
            this.lbRegister.Name = "lbRegister";
            this.lbRegister.Size = new System.Drawing.Size(123, 25);
            this.lbRegister.TabIndex = 6;
            this.lbRegister.TabStop = true;
            this.lbRegister.Text = "Register here";
            this.lbRegister.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbRegister_LinkClicked);
            // 
            // lbUsername
            // 
            this.lbUsername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbUsername.AutoSize = true;
            this.lbUsername.BackColor = System.Drawing.Color.White;
            this.lbUsername.Enabled = false;
            this.lbUsername.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsername.ForeColor = System.Drawing.Color.Silver;
            this.lbUsername.Location = new System.Drawing.Point(268, 192);
            this.lbUsername.Name = "lbUsername";
            this.lbUsername.Size = new System.Drawing.Size(53, 18);
            this.lbUsername.TabIndex = 5;
            this.lbUsername.Text = "Email";
            // 
            // lbPassword
            // 
            this.lbPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbPassword.AutoSize = true;
            this.lbPassword.BackColor = System.Drawing.Color.White;
            this.lbPassword.Enabled = false;
            this.lbPassword.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword.ForeColor = System.Drawing.Color.Silver;
            this.lbPassword.Location = new System.Drawing.Point(269, 248);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(85, 18);
            this.lbPassword.TabIndex = 5;
            this.lbPassword.Text = "Password";
            // 
            // lbWarning
            // 
            this.lbWarning.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbWarning.AutoSize = true;
            this.lbWarning.ForeColor = System.Drawing.Color.Firebrick;
            this.lbWarning.Location = new System.Drawing.Point(268, 278);
            this.lbWarning.Name = "lbWarning";
            this.lbWarning.Size = new System.Drawing.Size(0, 13);
            this.lbWarning.TabIndex = 9;
            this.lbWarning.Visible = false;
            // 
            // btnback_default
            // 
            this.btnback_default.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnback_default.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.backbutton_default;
            this.btnback_default.Location = new System.Drawing.Point(280, 703);
            this.btnback_default.Name = "btnback_default";
            this.btnback_default.Size = new System.Drawing.Size(17, 21);
            this.btnback_default.TabIndex = 8;
            this.btnback_default.TabStop = false;
            this.btnback_default.Click += new System.EventHandler(this.btnback_default_Click);
            this.btnback_default.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnback_default_MouseDown);
            this.btnback_default.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnback_default_MouseUp);
            // 
            // btnback
            // 
            this.btnback.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnback.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.backbutton;
            this.btnback.Location = new System.Drawing.Point(279, 703);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(17, 21);
            this.btnback.TabIndex = 8;
            this.btnback.TabStop = false;
            this.btnback.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox3.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox3.Location = new System.Drawing.Point(259, 185);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(289, 50);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox2.Location = new System.Drawing.Point(259, 241);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(289, 50);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // btnLogin
            // 
            this.btnLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLogin.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.button;
            this.btnLogin.Location = new System.Drawing.Point(420, 297);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(128, 50);
            this.btnLogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnLogin.TabIndex = 4;
            this.btnLogin.TabStop = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // pictureBox32
            // 
            this.pictureBox32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.pictureBox32.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.login_top_bar;
            this.pictureBox32.Location = new System.Drawing.Point(217, 83);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(377, 50);
            this.pictureBox32.TabIndex = 2;
            this.pictureBox32.TabStop = false;
            // 
            // pkeypad
            // 
            this.pkeypad.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pkeypad.BackgroundImage = global::PLDT_VirtualQueueSystem.Properties.Resources.on_screen_keyboard1;
            this.pkeypad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pkeypad.Controls.Add(this.newline);
            this.pkeypad.Controls.Add(this.backspace);
            this.pkeypad.Controls.Add(this.p);
            this.pkeypad.Controls.Add(this.l);
            this.pkeypad.Controls.Add(this.o);
            this.pkeypad.Controls.Add(this.k);
            this.pkeypad.Controls.Add(this.i);
            this.pkeypad.Controls.Add(this.space);
            this.pkeypad.Controls.Add(this.dot);
            this.pkeypad.Controls.Add(this.m);
            this.pkeypad.Controls.Add(this.j);
            this.pkeypad.Controls.Add(this.u);
            this.pkeypad.Controls.Add(this.n);
            this.pkeypad.Controls.Add(this.h);
            this.pkeypad.Controls.Add(this.y);
            this.pkeypad.Controls.Add(this.b);
            this.pkeypad.Controls.Add(this.g);
            this.pkeypad.Controls.Add(this.t);
            this.pkeypad.Controls.Add(this.v);
            this.pkeypad.Controls.Add(this.f);
            this.pkeypad.Controls.Add(this.c);
            this.pkeypad.Controls.Add(this.d);
            this.pkeypad.Controls.Add(this.x);
            this.pkeypad.Controls.Add(this.r);
            this.pkeypad.Controls.Add(this.s);
            this.pkeypad.Controls.Add(this.z);
            this.pkeypad.Controls.Add(this._e);
            this.pkeypad.Controls.Add(this.a);
            this.pkeypad.Controls.Add(this.w);
            this.pkeypad.Controls.Add(this.q);
            this.pkeypad.Location = new System.Drawing.Point(213, 434);
            this.pkeypad.Name = "pkeypad";
            this.pkeypad.Size = new System.Drawing.Size(381, 234);
            this.pkeypad.TabIndex = 1;
            this.pkeypad.Visible = false;
            // 
            // newline
            // 
            this.newline.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newline.BackgroundImage = global::PLDT_VirtualQueueSystem.Properties.Resources.newline;
            this.newline.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.newline1;
            this.newline.Location = new System.Drawing.Point(325, 179);
            this.newline.Name = "newline";
            this.newline.Size = new System.Drawing.Size(53, 53);
            this.newline.TabIndex = 2;
            this.newline.TabStop = false;
            this.newline.Visible = false;
            // 
            // backspace
            // 
            this.backspace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backspace.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.backspace;
            this.backspace.Location = new System.Drawing.Point(325, 121);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(53, 53);
            this.backspace.TabIndex = 2;
            this.backspace.TabStop = false;
            this.backspace.Visible = false;
            // 
            // p
            // 
            this.p.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.p.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.p.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.p;
            this.p.Location = new System.Drawing.Point(344, 5);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(34, 53);
            this.p.TabIndex = 0;
            this.p.TabStop = false;
            this.p.Visible = false;
            // 
            // l
            // 
            this.l.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.l.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.l;
            this.l.Location = new System.Drawing.Point(325, 63);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(34, 53);
            this.l.TabIndex = 0;
            this.l.TabStop = false;
            this.l.Visible = false;
            // 
            // o
            // 
            this.o.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.o.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.o.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.o;
            this.o.Location = new System.Drawing.Point(305, 5);
            this.o.Name = "o";
            this.o.Size = new System.Drawing.Size(34, 53);
            this.o.TabIndex = 0;
            this.o.TabStop = false;
            this.o.Visible = false;
            // 
            // k
            // 
            this.k.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.k.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.k.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.k;
            this.k.Location = new System.Drawing.Point(288, 63);
            this.k.Name = "k";
            this.k.Size = new System.Drawing.Size(34, 53);
            this.k.TabIndex = 0;
            this.k.TabStop = false;
            this.k.Visible = false;
            // 
            // i
            // 
            this.i.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.i.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.i.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.i;
            this.i.Location = new System.Drawing.Point(268, 5);
            this.i.Name = "i";
            this.i.Size = new System.Drawing.Size(34, 53);
            this.i.TabIndex = 0;
            this.i.TabStop = false;
            this.i.Visible = false;
            // 
            // space
            // 
            this.space.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.space.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.space.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.space;
            this.space.Location = new System.Drawing.Point(136, 179);
            this.space.Name = "space";
            this.space.Size = new System.Drawing.Size(146, 52);
            this.space.TabIndex = 0;
            this.space.TabStop = false;
            this.space.Visible = false;
            // 
            // dot
            // 
            this.dot.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.dot.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.dot;
            this.dot.Location = new System.Drawing.Point(288, 179);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(34, 53);
            this.dot.TabIndex = 0;
            this.dot.TabStop = false;
            this.dot.Visible = false;
            // 
            // m
            // 
            this.m.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.m.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.m;
            this.m.Location = new System.Drawing.Point(287, 121);
            this.m.Name = "m";
            this.m.Size = new System.Drawing.Size(34, 53);
            this.m.TabIndex = 0;
            this.m.TabStop = false;
            this.m.Visible = false;
            // 
            // j
            // 
            this.j.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.j.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.j;
            this.j.Location = new System.Drawing.Point(250, 63);
            this.j.Name = "j";
            this.j.Size = new System.Drawing.Size(34, 53);
            this.j.TabIndex = 0;
            this.j.TabStop = false;
            this.j.Visible = false;
            // 
            // u
            // 
            this.u.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.u.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.u.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.u;
            this.u.Location = new System.Drawing.Point(230, 5);
            this.u.Name = "u";
            this.u.Size = new System.Drawing.Size(34, 53);
            this.u.TabIndex = 0;
            this.u.TabStop = false;
            this.u.Visible = false;
            // 
            // n
            // 
            this.n.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.n.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.n.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.n;
            this.n.Location = new System.Drawing.Point(249, 121);
            this.n.Name = "n";
            this.n.Size = new System.Drawing.Size(34, 53);
            this.n.TabIndex = 0;
            this.n.TabStop = false;
            this.n.Visible = false;
            // 
            // h
            // 
            this.h.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.h.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.h.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.h;
            this.h.Location = new System.Drawing.Point(212, 63);
            this.h.Name = "h";
            this.h.Size = new System.Drawing.Size(34, 53);
            this.h.TabIndex = 0;
            this.h.TabStop = false;
            this.h.Visible = false;
            // 
            // y
            // 
            this.y.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.y.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.y.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.y;
            this.y.Location = new System.Drawing.Point(192, 5);
            this.y.Name = "y";
            this.y.Size = new System.Drawing.Size(34, 53);
            this.y.TabIndex = 0;
            this.y.TabStop = false;
            this.y.Visible = false;
            // 
            // b
            // 
            this.b.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.b.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.b;
            this.b.Location = new System.Drawing.Point(211, 121);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(34, 53);
            this.b.TabIndex = 0;
            this.b.TabStop = false;
            this.b.Visible = false;
            // 
            // g
            // 
            this.g.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.g.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.g.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.g;
            this.g.Location = new System.Drawing.Point(174, 63);
            this.g.Name = "g";
            this.g.Size = new System.Drawing.Size(34, 53);
            this.g.TabIndex = 0;
            this.g.TabStop = false;
            this.g.Visible = false;
            // 
            // t
            // 
            this.t.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.t.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.t.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.t;
            this.t.Location = new System.Drawing.Point(155, 5);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(34, 53);
            this.t.TabIndex = 0;
            this.t.TabStop = false;
            this.t.Visible = false;
            // 
            // v
            // 
            this.v.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.v.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.v.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.v;
            this.v.Location = new System.Drawing.Point(173, 121);
            this.v.Name = "v";
            this.v.Size = new System.Drawing.Size(34, 53);
            this.v.TabIndex = 0;
            this.v.TabStop = false;
            this.v.Visible = false;
            // 
            // f
            // 
            this.f.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.f.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.f.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.f;
            this.f.Location = new System.Drawing.Point(136, 63);
            this.f.Name = "f";
            this.f.Size = new System.Drawing.Size(34, 53);
            this.f.TabIndex = 0;
            this.f.TabStop = false;
            this.f.Visible = false;
            // 
            // c
            // 
            this.c.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.c.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.c;
            this.c.Location = new System.Drawing.Point(136, 121);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(34, 53);
            this.c.TabIndex = 0;
            this.c.TabStop = false;
            this.c.Visible = false;
            // 
            // d
            // 
            this.d.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.d.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.d;
            this.d.Location = new System.Drawing.Point(98, 63);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(34, 53);
            this.d.TabIndex = 0;
            this.d.TabStop = false;
            this.d.Visible = false;
            // 
            // x
            // 
            this.x.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.x.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.x.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.x;
            this.x.Location = new System.Drawing.Point(98, 121);
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(34, 53);
            this.x.TabIndex = 0;
            this.x.TabStop = false;
            this.x.Visible = false;
            // 
            // r
            // 
            this.r.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.r.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.r.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.r;
            this.r.Location = new System.Drawing.Point(117, 5);
            this.r.Name = "r";
            this.r.Size = new System.Drawing.Size(34, 53);
            this.r.TabIndex = 0;
            this.r.TabStop = false;
            this.r.Visible = false;
            // 
            // s
            // 
            this.s.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.s.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.s.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.s;
            this.s.Location = new System.Drawing.Point(60, 63);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(34, 53);
            this.s.TabIndex = 0;
            this.s.TabStop = false;
            this.s.Visible = false;
            // 
            // z
            // 
            this.z.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.z.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.z.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.z;
            this.z.Location = new System.Drawing.Point(60, 121);
            this.z.Name = "z";
            this.z.Size = new System.Drawing.Size(34, 53);
            this.z.TabIndex = 0;
            this.z.TabStop = false;
            this.z.Visible = false;
            // 
            // _e
            // 
            this._e.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._e.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this._e.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.e;
            this._e.Location = new System.Drawing.Point(79, 5);
            this._e.Name = "_e";
            this._e.Size = new System.Drawing.Size(34, 53);
            this._e.TabIndex = 0;
            this._e.TabStop = false;
            this._e.Visible = false;
            // 
            // a
            // 
            this.a.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.a.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.a;
            this.a.Location = new System.Drawing.Point(22, 63);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(34, 53);
            this.a.TabIndex = 0;
            this.a.TabStop = false;
            this.a.Visible = false;
            // 
            // w
            // 
            this.w.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.w.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.w.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.w;
            this.w.Location = new System.Drawing.Point(41, 5);
            this.w.Name = "w";
            this.w.Size = new System.Drawing.Size(34, 53);
            this.w.TabIndex = 0;
            this.w.TabStop = false;
            this.w.Visible = false;
            // 
            // q
            // 
            this.q.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.q.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.q;
            this.q.Location = new System.Drawing.Point(3, 5);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(34, 53);
            this.q.TabIndex = 0;
            this.q.TabStop = false;
            this.q.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.phone;
            this.pictureBox1.Location = new System.Drawing.Point(184, -31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(442, 842);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(810, 780);
            this.Controls.Add(this.lbWarning);
            this.Controls.Add(this.btnback_default);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.lbUsername);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbRegister);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pkeypad);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.btnback_default)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            this.pkeypad.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.newline)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backspace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.space)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.h)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._e)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pkeypad;
        private System.Windows.Forms.PictureBox q;
        private System.Windows.Forms.PictureBox p;
        private System.Windows.Forms.PictureBox o;
        private System.Windows.Forms.PictureBox i;
        private System.Windows.Forms.PictureBox u;
        private System.Windows.Forms.PictureBox y;
        private System.Windows.Forms.PictureBox t;
        private System.Windows.Forms.PictureBox r;
        private System.Windows.Forms.PictureBox _e;
        private System.Windows.Forms.PictureBox w;
        private System.Windows.Forms.PictureBox l;
        private System.Windows.Forms.PictureBox k;
        private System.Windows.Forms.PictureBox m;
        private System.Windows.Forms.PictureBox j;
        private System.Windows.Forms.PictureBox n;
        private System.Windows.Forms.PictureBox h;
        private System.Windows.Forms.PictureBox b;
        private System.Windows.Forms.PictureBox g;
        private System.Windows.Forms.PictureBox v;
        private System.Windows.Forms.PictureBox f;
        private System.Windows.Forms.PictureBox c;
        private System.Windows.Forms.PictureBox d;
        private System.Windows.Forms.PictureBox x;
        private System.Windows.Forms.PictureBox s;
        private System.Windows.Forms.PictureBox z;
        private System.Windows.Forms.PictureBox a;
        private System.Windows.Forms.PictureBox backspace;
        private System.Windows.Forms.PictureBox newline;
        private System.Windows.Forms.PictureBox dot;
        private System.Windows.Forms.PictureBox space;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.PictureBox btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel lbRegister;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbUsername;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.PictureBox btnback;
        private System.Windows.Forms.PictureBox btnback_default;
        private System.Windows.Forms.Label lbWarning;
    }
}

