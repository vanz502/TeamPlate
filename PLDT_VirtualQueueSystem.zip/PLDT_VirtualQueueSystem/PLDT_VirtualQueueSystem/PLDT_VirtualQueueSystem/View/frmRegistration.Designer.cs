﻿namespace PLDT_VirtualQueueSystem.View
{
    partial class frmRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbLastname = new System.Windows.Forms.Label();
            this.txtLastname = new System.Windows.Forms.TextBox();
            this.pBackpanel = new System.Windows.Forms.Panel();
            this.lbWarning = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lbMiddlename = new System.Windows.Forms.Label();
            this.lbNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbAddress = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lbPass = new System.Windows.Forms.Label();
            this.lbUser = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.lbAccountno = new System.Windows.Forms.Label();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.txtAccountno = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbFirstname = new System.Windows.Forms.Label();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnback_default = new System.Windows.Forms.PictureBox();
            this.btnback = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pkeypad = new System.Windows.Forms.Panel();
            this.newline = new System.Windows.Forms.PictureBox();
            this.backspace = new System.Windows.Forms.PictureBox();
            this.p = new System.Windows.Forms.PictureBox();
            this.l = new System.Windows.Forms.PictureBox();
            this.o = new System.Windows.Forms.PictureBox();
            this.k = new System.Windows.Forms.PictureBox();
            this.i = new System.Windows.Forms.PictureBox();
            this.space = new System.Windows.Forms.PictureBox();
            this.dot = new System.Windows.Forms.PictureBox();
            this.m = new System.Windows.Forms.PictureBox();
            this.j = new System.Windows.Forms.PictureBox();
            this.u = new System.Windows.Forms.PictureBox();
            this.n = new System.Windows.Forms.PictureBox();
            this.h = new System.Windows.Forms.PictureBox();
            this.y = new System.Windows.Forms.PictureBox();
            this.b = new System.Windows.Forms.PictureBox();
            this.g = new System.Windows.Forms.PictureBox();
            this.t = new System.Windows.Forms.PictureBox();
            this.v = new System.Windows.Forms.PictureBox();
            this.f = new System.Windows.Forms.PictureBox();
            this.c = new System.Windows.Forms.PictureBox();
            this.d = new System.Windows.Forms.PictureBox();
            this.x = new System.Windows.Forms.PictureBox();
            this.r = new System.Windows.Forms.PictureBox();
            this.s = new System.Windows.Forms.PictureBox();
            this.z = new System.Windows.Forms.PictureBox();
            this._e = new System.Windows.Forms.PictureBox();
            this.a = new System.Windows.Forms.PictureBox();
            this.w = new System.Windows.Forms.PictureBox();
            this.q = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pBackpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnback_default)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            this.pkeypad.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.newline)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backspace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.l)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.o)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.k)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.space)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.h)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.v)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._e)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.q)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbLastname
            // 
            this.lbLastname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbLastname.AutoSize = true;
            this.lbLastname.BackColor = System.Drawing.Color.White;
            this.lbLastname.Enabled = false;
            this.lbLastname.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLastname.ForeColor = System.Drawing.Color.Silver;
            this.lbLastname.Location = new System.Drawing.Point(53, 65);
            this.lbLastname.Name = "lbLastname";
            this.lbLastname.Size = new System.Drawing.Size(96, 18);
            this.lbLastname.TabIndex = 9;
            this.lbLastname.Text = "Last Name";
            // 
            // txtLastname
            // 
            this.txtLastname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtLastname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLastname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastname.Location = new System.Drawing.Point(47, 60);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(280, 26);
            this.txtLastname.TabIndex = 8;
            this.txtLastname.TabStop = false;
            this.txtLastname.TextChanged += new System.EventHandler(this.txtLastname_TextChanged);
            this.txtLastname.Click += new System.EventHandler(this.txtUsername_Click);
            this.txtLastname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtLastname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtLastname.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // pBackpanel
            // 
            this.pBackpanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pBackpanel.Controls.Add(this.lbWarning);
            this.pBackpanel.Controls.Add(this.label6);
            this.pBackpanel.Controls.Add(this.btnRegister);
            this.pBackpanel.Controls.Add(this.comboBox1);
            this.pBackpanel.Controls.Add(this.lbMiddlename);
            this.pBackpanel.Controls.Add(this.lbNumber);
            this.pBackpanel.Controls.Add(this.label1);
            this.pBackpanel.Controls.Add(this.label7);
            this.pBackpanel.Controls.Add(this.lbAddress);
            this.pBackpanel.Controls.Add(this.txtNumber);
            this.pBackpanel.Controls.Add(this.txtAddress);
            this.pBackpanel.Controls.Add(this.lbPass);
            this.pBackpanel.Controls.Add(this.lbUser);
            this.pBackpanel.Controls.Add(this.txtPass);
            this.pBackpanel.Controls.Add(this.lbAccountno);
            this.pBackpanel.Controls.Add(this.txtUser);
            this.pBackpanel.Controls.Add(this.pictureBox7);
            this.pBackpanel.Controls.Add(this.txtAccountno);
            this.pBackpanel.Controls.Add(this.pictureBox9);
            this.pBackpanel.Controls.Add(this.pictureBox6);
            this.pBackpanel.Controls.Add(this.pictureBox8);
            this.pBackpanel.Controls.Add(this.lbLastname);
            this.pBackpanel.Controls.Add(this.pictureBox5);
            this.pBackpanel.Controls.Add(this.txtLastname);
            this.pBackpanel.Controls.Add(this.pictureBox3);
            this.pBackpanel.Controls.Add(this.lbFirstname);
            this.pBackpanel.Controls.Add(this.txtFirstname);
            this.pBackpanel.Controls.Add(this.txtMiddleName);
            this.pBackpanel.Controls.Add(this.pictureBox4);
            this.pBackpanel.Controls.Add(this.pictureBox2);
            this.pBackpanel.Location = new System.Drawing.Point(217, 135);
            this.pBackpanel.Name = "pBackpanel";
            this.pBackpanel.Size = new System.Drawing.Size(377, 534);
            this.pBackpanel.TabIndex = 12;
            this.pBackpanel.Click += new System.EventHandler(this.pBackpanel_Click);
            // 
            // lbWarning
            // 
            this.lbWarning.AutoSize = true;
            this.lbWarning.ForeColor = System.Drawing.Color.Firebrick;
            this.lbWarning.Location = new System.Drawing.Point(66, 624);
            this.lbWarning.Name = "lbWarning";
            this.lbWarning.Size = new System.Drawing.Size(11, 13);
            this.lbWarning.TabIndex = 17;
            this.lbWarning.Text = "*";
            this.lbWarning.Visible = false;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(159)))), ((int)(((byte)(159)))));
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(133, 595);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 18);
            this.label6.TabIndex = 16;
            this.label6.Text = "Register";
            // 
            // btnRegister
            // 
            this.btnRegister.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRegister.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.button;
            this.btnRegister.Location = new System.Drawing.Point(121, 579);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(205, 46);
            this.btnRegister.TabIndex = 15;
            this.btnRegister.TabStop = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBox1.Location = new System.Drawing.Point(155, 183);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(178, 33);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.Enter += new System.EventHandler(this.comboBox1_Enter);
            // 
            // lbMiddlename
            // 
            this.lbMiddlename.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbMiddlename.AutoSize = true;
            this.lbMiddlename.BackColor = System.Drawing.Color.White;
            this.lbMiddlename.Enabled = false;
            this.lbMiddlename.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMiddlename.ForeColor = System.Drawing.Color.Silver;
            this.lbMiddlename.Location = new System.Drawing.Point(53, 7);
            this.lbMiddlename.Name = "lbMiddlename";
            this.lbMiddlename.Size = new System.Drawing.Size(114, 18);
            this.lbMiddlename.TabIndex = 12;
            this.lbMiddlename.Text = "Middle Name";
            // 
            // lbNumber
            // 
            this.lbNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbNumber.AutoSize = true;
            this.lbNumber.BackColor = System.Drawing.Color.White;
            this.lbNumber.Enabled = false;
            this.lbNumber.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumber.ForeColor = System.Drawing.Color.Silver;
            this.lbNumber.Location = new System.Drawing.Point(55, 356);
            this.lbNumber.Name = "lbNumber";
            this.lbNumber.Size = new System.Drawing.Size(125, 18);
            this.lbNumber.TabIndex = 9;
            this.lbNumber.Text = "Phone number";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(6, 235);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(365, 18);
            this.label1.TabIndex = 9;
            this.label1.Text = "---------------------------------------------------";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Silver;
            this.label7.Location = new System.Drawing.Point(55, 191);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 18);
            this.label7.TabIndex = 9;
            this.label7.Text = "Gender";
            // 
            // lbAddress
            // 
            this.lbAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbAddress.AutoSize = true;
            this.lbAddress.BackColor = System.Drawing.Color.White;
            this.lbAddress.Enabled = false;
            this.lbAddress.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAddress.ForeColor = System.Drawing.Color.Silver;
            this.lbAddress.Location = new System.Drawing.Point(53, 124);
            this.lbAddress.Name = "lbAddress";
            this.lbAddress.Size = new System.Drawing.Size(73, 18);
            this.lbAddress.TabIndex = 9;
            this.lbAddress.Text = "Address";
            // 
            // txtNumber
            // 
            this.txtNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumber.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumber.Location = new System.Drawing.Point(47, 351);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(280, 26);
            this.txtNumber.TabIndex = 8;
            this.txtNumber.TabStop = false;
            this.txtNumber.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            this.txtNumber.Click += new System.EventHandler(this.txtUsername_Click);
            this.txtNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtNumber.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtNumber.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // txtAddress
            // 
            this.txtAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(47, 119);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(280, 26);
            this.txtAddress.TabIndex = 8;
            this.txtAddress.TabStop = false;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
            this.txtAddress.Click += new System.EventHandler(this.txtUsername_Click);
            this.txtAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtAddress.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtAddress.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // lbPass
            // 
            this.lbPass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbPass.AutoSize = true;
            this.lbPass.BackColor = System.Drawing.Color.White;
            this.lbPass.Enabled = false;
            this.lbPass.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPass.ForeColor = System.Drawing.Color.Silver;
            this.lbPass.Location = new System.Drawing.Point(55, 480);
            this.lbPass.Name = "lbPass";
            this.lbPass.Size = new System.Drawing.Size(85, 18);
            this.lbPass.TabIndex = 9;
            this.lbPass.Text = "Password";
            // 
            // lbUser
            // 
            this.lbUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbUser.AutoSize = true;
            this.lbUser.BackColor = System.Drawing.Color.White;
            this.lbUser.Enabled = false;
            this.lbUser.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser.ForeColor = System.Drawing.Color.Silver;
            this.lbUser.Location = new System.Drawing.Point(55, 417);
            this.lbUser.Name = "lbUser";
            this.lbUser.Size = new System.Drawing.Size(90, 18);
            this.lbUser.TabIndex = 9;
            this.lbUser.Text = "Username";
            // 
            // txtPass
            // 
            this.txtPass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPass.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass.Location = new System.Drawing.Point(46, 475);
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*';
            this.txtPass.Size = new System.Drawing.Size(280, 26);
            this.txtPass.TabIndex = 8;
            this.txtPass.TabStop = false;
            this.txtPass.TextChanged += new System.EventHandler(this.txtPass2_TextChanged);
            this.txtPass.Click += new System.EventHandler(this.txtUsername_Click);
            this.txtPass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtPass.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtPass.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // lbAccountno
            // 
            this.lbAccountno.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbAccountno.AutoSize = true;
            this.lbAccountno.BackColor = System.Drawing.Color.White;
            this.lbAccountno.Enabled = false;
            this.lbAccountno.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAccountno.ForeColor = System.Drawing.Color.Silver;
            this.lbAccountno.Location = new System.Drawing.Point(55, 296);
            this.lbAccountno.Name = "lbAccountno";
            this.lbAccountno.Size = new System.Drawing.Size(100, 18);
            this.lbAccountno.TabIndex = 9;
            this.lbAccountno.Text = "Account No";
            // 
            // txtUser
            // 
            this.txtUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUser.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.Location = new System.Drawing.Point(47, 412);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(280, 26);
            this.txtUser.TabIndex = 8;
            this.txtUser.TabStop = false;
            this.txtUser.TextChanged += new System.EventHandler(this.txtPass_TextChanged);
            this.txtUser.Click += new System.EventHandler(this.txtUsername_Click);
            this.txtUser.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtUser.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtUser.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox7.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox7.Location = new System.Drawing.Point(44, 349);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(289, 50);
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            // 
            // txtAccountno
            // 
            this.txtAccountno.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAccountno.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAccountno.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountno.Location = new System.Drawing.Point(47, 291);
            this.txtAccountno.Name = "txtAccountno";
            this.txtAccountno.Size = new System.Drawing.Size(280, 26);
            this.txtAccountno.TabIndex = 8;
            this.txtAccountno.TabStop = false;
            this.txtAccountno.TextChanged += new System.EventHandler(this.txtAccountno_TextChanged);
            this.txtAccountno.Click += new System.EventHandler(this.txtUsername_Click);
            this.txtAccountno.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtAccountno.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            this.txtAccountno.Enter += new System.EventHandler(this.txtUsername_Enter);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox9.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox9.Location = new System.Drawing.Point(43, 473);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(289, 50);
            this.pictureBox9.TabIndex = 10;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox6.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox6.Location = new System.Drawing.Point(44, 117);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(289, 50);
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox8.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox8.Location = new System.Drawing.Point(44, 410);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(289, 50);
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox5.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox5.Location = new System.Drawing.Point(44, 289);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(289, 50);
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox3.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox3.Location = new System.Drawing.Point(44, 58);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(289, 50);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // lbFirstname
            // 
            this.lbFirstname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbFirstname.AutoSize = true;
            this.lbFirstname.BackColor = System.Drawing.Color.White;
            this.lbFirstname.Enabled = false;
            this.lbFirstname.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFirstname.ForeColor = System.Drawing.Color.Silver;
            this.lbFirstname.Location = new System.Drawing.Point(52, -52);
            this.lbFirstname.Name = "lbFirstname";
            this.lbFirstname.Size = new System.Drawing.Size(97, 18);
            this.lbFirstname.TabIndex = 12;
            this.lbFirstname.Text = "First Name";
            // 
            // txtFirstname
            // 
            this.txtFirstname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFirstname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFirstname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstname.Location = new System.Drawing.Point(46, -57);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(280, 26);
            this.txtFirstname.TabIndex = 11;
            this.txtFirstname.TabStop = false;
            this.txtFirstname.TextChanged += new System.EventHandler(this.txtFirstname_TextChanged);
            this.txtFirstname.Click += new System.EventHandler(this.txtPass_Click);
            this.txtFirstname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtFirstname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMiddleName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMiddleName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiddleName.Location = new System.Drawing.Point(47, 2);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(280, 26);
            this.txtMiddleName.TabIndex = 11;
            this.txtMiddleName.TabStop = false;
            this.txtMiddleName.TextChanged += new System.EventHandler(this.txtMiddleName_TextChanged);
            this.txtMiddleName.Click += new System.EventHandler(this.txtMiddleName_Click);
            this.txtMiddleName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddleName_KeyDown_1);
            this.txtMiddleName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUsername_KeyUp);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox4.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox4.Location = new System.Drawing.Point(44, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(289, 50);
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.textbox;
            this.pictureBox2.Location = new System.Drawing.Point(43, -59);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(289, 50);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // btnback_default
            // 
            this.btnback_default.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnback_default.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.backbutton_default;
            this.btnback_default.Location = new System.Drawing.Point(281, 705);
            this.btnback_default.Name = "btnback_default";
            this.btnback_default.Size = new System.Drawing.Size(17, 21);
            this.btnback_default.TabIndex = 14;
            this.btnback_default.TabStop = false;
            this.btnback_default.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnback_default_MouseDown);
            this.btnback_default.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnback_default_MouseUp);
            // 
            // btnback
            // 
            this.btnback.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnback.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.backbutton;
            this.btnback.Location = new System.Drawing.Point(281, 705);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(17, 21);
            this.btnback.TabIndex = 13;
            this.btnback.TabStop = false;
            this.btnback.Visible = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.pictureBox32.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.register_top_bar;
            this.pictureBox32.Location = new System.Drawing.Point(217, 85);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(377, 50);
            this.pictureBox32.TabIndex = 11;
            this.pictureBox32.TabStop = false;
            // 
            // pkeypad
            // 
            this.pkeypad.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pkeypad.BackgroundImage = global::PLDT_VirtualQueueSystem.Properties.Resources.on_screen_keyboard1;
            this.pkeypad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pkeypad.Controls.Add(this.newline);
            this.pkeypad.Controls.Add(this.backspace);
            this.pkeypad.Controls.Add(this.p);
            this.pkeypad.Controls.Add(this.l);
            this.pkeypad.Controls.Add(this.o);
            this.pkeypad.Controls.Add(this.k);
            this.pkeypad.Controls.Add(this.i);
            this.pkeypad.Controls.Add(this.space);
            this.pkeypad.Controls.Add(this.dot);
            this.pkeypad.Controls.Add(this.m);
            this.pkeypad.Controls.Add(this.j);
            this.pkeypad.Controls.Add(this.u);
            this.pkeypad.Controls.Add(this.n);
            this.pkeypad.Controls.Add(this.h);
            this.pkeypad.Controls.Add(this.y);
            this.pkeypad.Controls.Add(this.b);
            this.pkeypad.Controls.Add(this.g);
            this.pkeypad.Controls.Add(this.t);
            this.pkeypad.Controls.Add(this.v);
            this.pkeypad.Controls.Add(this.f);
            this.pkeypad.Controls.Add(this.c);
            this.pkeypad.Controls.Add(this.d);
            this.pkeypad.Controls.Add(this.x);
            this.pkeypad.Controls.Add(this.r);
            this.pkeypad.Controls.Add(this.s);
            this.pkeypad.Controls.Add(this.z);
            this.pkeypad.Controls.Add(this._e);
            this.pkeypad.Controls.Add(this.a);
            this.pkeypad.Controls.Add(this.w);
            this.pkeypad.Controls.Add(this.q);
            this.pkeypad.Location = new System.Drawing.Point(217, 436);
            this.pkeypad.Name = "pkeypad";
            this.pkeypad.Size = new System.Drawing.Size(377, 234);
            this.pkeypad.TabIndex = 3;
            this.pkeypad.Visible = false;
            // 
            // newline
            // 
            this.newline.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.newline.BackgroundImage = global::PLDT_VirtualQueueSystem.Properties.Resources.newline;
            this.newline.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.newline1;
            this.newline.Location = new System.Drawing.Point(322, 178);
            this.newline.Name = "newline";
            this.newline.Size = new System.Drawing.Size(53, 53);
            this.newline.TabIndex = 31;
            this.newline.TabStop = false;
            this.newline.Visible = false;
            // 
            // backspace
            // 
            this.backspace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backspace.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.backspace;
            this.backspace.Location = new System.Drawing.Point(322, 120);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(53, 53);
            this.backspace.TabIndex = 32;
            this.backspace.TabStop = false;
            this.backspace.Visible = false;
            // 
            // p
            // 
            this.p.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.p.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.p.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.p;
            this.p.Location = new System.Drawing.Point(340, 6);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(34, 53);
            this.p.TabIndex = 22;
            this.p.TabStop = false;
            this.p.Visible = false;
            // 
            // l
            // 
            this.l.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.l.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.l.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.l;
            this.l.Location = new System.Drawing.Point(322, 63);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(34, 53);
            this.l.TabIndex = 23;
            this.l.TabStop = false;
            this.l.Visible = false;
            // 
            // o
            // 
            this.o.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.o.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.o.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.o;
            this.o.Location = new System.Drawing.Point(303, 5);
            this.o.Name = "o";
            this.o.Size = new System.Drawing.Size(34, 53);
            this.o.TabIndex = 18;
            this.o.TabStop = false;
            this.o.Visible = false;
            // 
            // k
            // 
            this.k.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.k.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.k.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.k;
            this.k.Location = new System.Drawing.Point(285, 63);
            this.k.Name = "k";
            this.k.Size = new System.Drawing.Size(34, 53);
            this.k.TabIndex = 19;
            this.k.TabStop = false;
            this.k.Visible = false;
            // 
            // i
            // 
            this.i.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.i.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.i.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.i;
            this.i.Location = new System.Drawing.Point(265, 5);
            this.i.Name = "i";
            this.i.Size = new System.Drawing.Size(34, 53);
            this.i.TabIndex = 20;
            this.i.TabStop = false;
            this.i.Visible = false;
            // 
            // space
            // 
            this.space.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.space.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.space.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.space;
            this.space.Location = new System.Drawing.Point(133, 179);
            this.space.Name = "space";
            this.space.Size = new System.Drawing.Size(146, 52);
            this.space.TabIndex = 24;
            this.space.TabStop = false;
            this.space.Visible = false;
            // 
            // dot
            // 
            this.dot.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.dot.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.dot;
            this.dot.Location = new System.Drawing.Point(286, 178);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(34, 53);
            this.dot.TabIndex = 28;
            this.dot.TabStop = false;
            this.dot.Visible = false;
            // 
            // m
            // 
            this.m.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.m.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.m;
            this.m.Location = new System.Drawing.Point(285, 120);
            this.m.Name = "m";
            this.m.Size = new System.Drawing.Size(34, 53);
            this.m.TabIndex = 29;
            this.m.TabStop = false;
            this.m.Visible = false;
            // 
            // j
            // 
            this.j.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.j.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.j;
            this.j.Location = new System.Drawing.Point(247, 63);
            this.j.Name = "j";
            this.j.Size = new System.Drawing.Size(34, 53);
            this.j.TabIndex = 30;
            this.j.TabStop = false;
            this.j.Visible = false;
            // 
            // u
            // 
            this.u.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.u.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.u.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.u;
            this.u.Location = new System.Drawing.Point(228, 5);
            this.u.Name = "u";
            this.u.Size = new System.Drawing.Size(34, 53);
            this.u.TabIndex = 25;
            this.u.TabStop = false;
            this.u.Visible = false;
            // 
            // n
            // 
            this.n.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.n.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.n.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.n;
            this.n.Location = new System.Drawing.Point(247, 120);
            this.n.Name = "n";
            this.n.Size = new System.Drawing.Size(34, 53);
            this.n.TabIndex = 26;
            this.n.TabStop = false;
            this.n.Visible = false;
            // 
            // h
            // 
            this.h.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.h.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.h.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.h;
            this.h.Location = new System.Drawing.Point(209, 63);
            this.h.Name = "h";
            this.h.Size = new System.Drawing.Size(34, 53);
            this.h.TabIndex = 27;
            this.h.TabStop = false;
            this.h.Visible = false;
            // 
            // y
            // 
            this.y.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.y.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.y.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.y;
            this.y.Location = new System.Drawing.Point(190, 5);
            this.y.Name = "y";
            this.y.Size = new System.Drawing.Size(34, 53);
            this.y.TabIndex = 21;
            this.y.TabStop = false;
            this.y.Visible = false;
            // 
            // b
            // 
            this.b.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.b.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.b.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.b;
            this.b.Location = new System.Drawing.Point(209, 120);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(34, 53);
            this.b.TabIndex = 7;
            this.b.TabStop = false;
            this.b.Visible = false;
            // 
            // g
            // 
            this.g.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.g.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.g.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.g;
            this.g.Location = new System.Drawing.Point(171, 63);
            this.g.Name = "g";
            this.g.Size = new System.Drawing.Size(34, 53);
            this.g.TabIndex = 8;
            this.g.TabStop = false;
            this.g.Visible = false;
            // 
            // t
            // 
            this.t.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.t.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.t.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.t;
            this.t.Location = new System.Drawing.Point(153, 5);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(34, 53);
            this.t.TabIndex = 9;
            this.t.TabStop = false;
            this.t.Visible = false;
            // 
            // v
            // 
            this.v.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.v.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.v.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.v;
            this.v.Location = new System.Drawing.Point(171, 120);
            this.v.Name = "v";
            this.v.Size = new System.Drawing.Size(34, 53);
            this.v.TabIndex = 6;
            this.v.TabStop = false;
            this.v.Visible = false;
            // 
            // f
            // 
            this.f.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.f.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.f.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.f;
            this.f.Location = new System.Drawing.Point(134, 63);
            this.f.Name = "f";
            this.f.Size = new System.Drawing.Size(34, 53);
            this.f.TabIndex = 3;
            this.f.TabStop = false;
            this.f.Visible = false;
            // 
            // c
            // 
            this.c.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.c.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.c.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.c;
            this.c.Location = new System.Drawing.Point(134, 120);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(34, 53);
            this.c.TabIndex = 4;
            this.c.TabStop = false;
            this.c.Visible = false;
            // 
            // d
            // 
            this.d.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.d.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.d.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.d;
            this.d.Location = new System.Drawing.Point(97, 63);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(34, 53);
            this.d.TabIndex = 5;
            this.d.TabStop = false;
            this.d.Visible = false;
            // 
            // x
            // 
            this.x.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.x.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.x.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.x;
            this.x.Location = new System.Drawing.Point(96, 120);
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(34, 53);
            this.x.TabIndex = 14;
            this.x.TabStop = false;
            this.x.Visible = false;
            // 
            // r
            // 
            this.r.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.r.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.r.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.r;
            this.r.Location = new System.Drawing.Point(115, 5);
            this.r.Name = "r";
            this.r.Size = new System.Drawing.Size(34, 53);
            this.r.TabIndex = 15;
            this.r.TabStop = false;
            this.r.Visible = false;
            // 
            // s
            // 
            this.s.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.s.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.s.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.s;
            this.s.Location = new System.Drawing.Point(59, 63);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(34, 53);
            this.s.TabIndex = 16;
            this.s.TabStop = false;
            this.s.Visible = false;
            // 
            // z
            // 
            this.z.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.z.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.z.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.z;
            this.z.Location = new System.Drawing.Point(58, 120);
            this.z.Name = "z";
            this.z.Size = new System.Drawing.Size(34, 53);
            this.z.TabIndex = 13;
            this.z.TabStop = false;
            this.z.Visible = false;
            // 
            // _e
            // 
            this._e.Anchor = System.Windows.Forms.AnchorStyles.None;
            this._e.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this._e.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.e;
            this._e.Location = new System.Drawing.Point(78, 5);
            this._e.Name = "_e";
            this._e.Size = new System.Drawing.Size(34, 53);
            this._e.TabIndex = 10;
            this._e.TabStop = false;
            this._e.Visible = false;
            // 
            // a
            // 
            this.a.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.a.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.a.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.a;
            this.a.Location = new System.Drawing.Point(21, 63);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(34, 53);
            this.a.TabIndex = 11;
            this.a.TabStop = false;
            this.a.Visible = false;
            // 
            // w
            // 
            this.w.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.w.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.w.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.w;
            this.w.Location = new System.Drawing.Point(40, 5);
            this.w.Name = "w";
            this.w.Size = new System.Drawing.Size(34, 53);
            this.w.TabIndex = 12;
            this.w.TabStop = false;
            this.w.Visible = false;
            // 
            // q
            // 
            this.q.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.q.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.q;
            this.q.Location = new System.Drawing.Point(3, 5);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(34, 53);
            this.q.TabIndex = 17;
            this.q.TabStop = false;
            this.q.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::PLDT_VirtualQueueSystem.Properties.Resources.phone;
            this.pictureBox1.Location = new System.Drawing.Point(184, -29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(442, 842);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // frmRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(810, 784);
            this.Controls.Add(this.btnback_default);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pkeypad);
            this.Controls.Add(this.pBackpanel);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmRegistration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmRegistration";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pBackpanel.ResumeLayout(false);
            this.pBackpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnback_default)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            this.pkeypad.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.newline)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backspace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.l)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.o)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.k)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.space)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.h)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.v)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._e)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.q)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pkeypad;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbLastname;
        private System.Windows.Forms.TextBox txtLastname;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.Panel pBackpanel;
        private System.Windows.Forms.PictureBox btnback_default;
        private System.Windows.Forms.PictureBox btnback;
        private System.Windows.Forms.Label lbMiddlename;
        private System.Windows.Forms.Label lbFirstname;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox newline;
        private System.Windows.Forms.PictureBox backspace;
        private System.Windows.Forms.PictureBox p;
        private System.Windows.Forms.PictureBox l;
        private System.Windows.Forms.PictureBox o;
        private System.Windows.Forms.PictureBox k;
        private System.Windows.Forms.PictureBox i;
        private System.Windows.Forms.PictureBox space;
        private System.Windows.Forms.PictureBox dot;
        private System.Windows.Forms.PictureBox m;
        private System.Windows.Forms.PictureBox j;
        private System.Windows.Forms.PictureBox u;
        private System.Windows.Forms.PictureBox n;
        private System.Windows.Forms.PictureBox h;
        private System.Windows.Forms.PictureBox y;
        private System.Windows.Forms.PictureBox b;
        private System.Windows.Forms.PictureBox g;
        private System.Windows.Forms.PictureBox t;
        private System.Windows.Forms.PictureBox v;
        private System.Windows.Forms.PictureBox f;
        private System.Windows.Forms.PictureBox c;
        private System.Windows.Forms.PictureBox d;
        private System.Windows.Forms.PictureBox x;
        private System.Windows.Forms.PictureBox r;
        private System.Windows.Forms.PictureBox s;
        private System.Windows.Forms.PictureBox z;
        private System.Windows.Forms.PictureBox _e;
        private System.Windows.Forms.PictureBox a;
        private System.Windows.Forms.PictureBox w;
        private System.Windows.Forms.PictureBox q;
        private System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lbAccountno;
        private System.Windows.Forms.TextBox txtAccountno;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lbNumber;
        private System.Windows.Forms.Label lbAddress;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label lbPass;
        private System.Windows.Forms.Label lbUser;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox btnRegister;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbWarning;
        private System.Windows.Forms.Label label1;
    }
}