﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PLDT_VirtualQueueSystem.View
{
    public partial class frmProfile : Form
    {
        int x;
        public frmProfile()
        {
            InitializeComponent();
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
            else if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            p.Visible = true;
            menupanel.Visible = false;
        }

        private void btnback_default_MouseDown(object sender, MouseEventArgs e)
        {
            btnback.Visible = true;
            btnback_default.Visible = false;
        }

        private void btnback_default_MouseUp(object sender, MouseEventArgs e)
        {
            btnback.Visible = false;
            btnback_default.Visible = true;
            frmMain form = new frmMain();
            form.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            p.Visible = false;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            frmLogin x = new frmLogin();
            x.Show();
            this.Hide();
        }
    }
}
