﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PLDT_VirtualQueueSystem.View
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            pBackpanel.AutoScrollMinSize = new Size(0, 1300);
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            var form = new frmLogin();
            form.Show();
            this.Hide();
        }
    }
}
