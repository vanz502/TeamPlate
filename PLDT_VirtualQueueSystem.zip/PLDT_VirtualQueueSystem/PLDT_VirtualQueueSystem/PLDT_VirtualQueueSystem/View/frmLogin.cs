﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PLDT_VirtualQueueSystem.View;

namespace PLDT_VirtualQueueSystem
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void txtUsername_Enter(object sender, EventArgs e)
        {
            pkeypad.Visible = true;
        }

        private void txtUsername_Leave(object sender, EventArgs e)
        {
            pkeypad.Visible = false;
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            pkeypad.Visible = true;
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            pkeypad.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pkeypad.Visible = false;
        }

        private void txtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Q) q.Visible = true;
            else if (e.KeyCode == Keys.W) w.Visible = true;
            else if (e.KeyCode == Keys.E) _e.Visible = true;
            else if (e.KeyCode == Keys.R) r.Visible = true;
            else if (e.KeyCode == Keys.T) t.Visible = true;
            else if (e.KeyCode == Keys.Y) y.Visible = true;
            else if (e.KeyCode == Keys.U) u.Visible = true;
            else if (e.KeyCode == Keys.I) i.Visible = true;
            else if (e.KeyCode == Keys.O) o.Visible = true;
            else if (e.KeyCode == Keys.P) p.Visible = true;
            else if (e.KeyCode == Keys.A) a.Visible = true;
            else if (e.KeyCode == Keys.S) s.Visible = true;
            else if (e.KeyCode == Keys.D) d.Visible = true;
            else if (e.KeyCode == Keys.F) f.Visible = true;
            else if (e.KeyCode == Keys.G) g.Visible = true;
            else if (e.KeyCode == Keys.H) h.Visible = true;
            else if (e.KeyCode == Keys.J) j.Visible = true;
            else if (e.KeyCode == Keys.K) k.Visible = true;
            else if (e.KeyCode == Keys.L) l.Visible = true;
            else if (e.KeyCode == Keys.Z) z.Visible = true;
            else if (e.KeyCode == Keys.X) x.Visible = true;
            else if (e.KeyCode == Keys.C) c.Visible = true;
            else if (e.KeyCode == Keys.V) v.Visible = true;
            else if (e.KeyCode == Keys.B) b.Visible = true;
            else if (e.KeyCode == Keys.N) n.Visible = true;
            else if (e.KeyCode == Keys.M) m.Visible = true;
            else if (e.KeyCode == Keys.Back) backspace.Visible = true;
            else if (e.KeyCode == Keys.Enter) newline.Visible = true;
            else if (e.KeyCode == Keys.Space) space.Visible = true;

        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Q) q.Visible = true;
            else if (e.KeyCode == Keys.W) w.Visible = true;
            else if (e.KeyCode == Keys.E) _e.Visible = true;
            else if (e.KeyCode == Keys.R) r.Visible = true;
            else if (e.KeyCode == Keys.T) t.Visible = true;
            else if (e.KeyCode == Keys.Y) y.Visible = true;
            else if (e.KeyCode == Keys.U) u.Visible = true;
            else if (e.KeyCode == Keys.I) i.Visible = true;
            else if (e.KeyCode == Keys.O) o.Visible = true;
            else if (e.KeyCode == Keys.P) p.Visible = true;
            else if (e.KeyCode == Keys.A) a.Visible = true;
            else if (e.KeyCode == Keys.S) s.Visible = true;
            else if (e.KeyCode == Keys.D) d.Visible = true;
            else if (e.KeyCode == Keys.F) f.Visible = true;
            else if (e.KeyCode == Keys.G) g.Visible = true;
            else if (e.KeyCode == Keys.H) h.Visible = true;
            else if (e.KeyCode == Keys.J) j.Visible = true;
            else if (e.KeyCode == Keys.K) k.Visible = true;
            else if (e.KeyCode == Keys.L) l.Visible = true;
            else if (e.KeyCode == Keys.Z) z.Visible = true;
            else if (e.KeyCode == Keys.X) x.Visible = true;
            else if (e.KeyCode == Keys.C) c.Visible = true;
            else if (e.KeyCode == Keys.V) v.Visible = true;
            else if (e.KeyCode == Keys.B) b.Visible = true;
            else if (e.KeyCode == Keys.N) n.Visible = true;
            else if (e.KeyCode == Keys.M) m.Visible = true;
            else if (e.KeyCode == Keys.Back) backspace.Visible = true;
            else if (e.KeyCode == Keys.Enter) newline.Visible = true;
            else if (e.KeyCode == Keys.Space) space.Visible = true;
        }

        private void txtPassword_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Q) q.Visible = false;
            else if (e.KeyCode == Keys.W) w.Visible = false;
            else if (e.KeyCode == Keys.E) _e.Visible = false;
            else if (e.KeyCode == Keys.R) r.Visible = false;
            else if (e.KeyCode == Keys.T) t.Visible = false;
            else if (e.KeyCode == Keys.Y) y.Visible = false;
            else if (e.KeyCode == Keys.U) u.Visible = false;
            else if (e.KeyCode == Keys.I) i.Visible = false;
            else if (e.KeyCode == Keys.O) o.Visible = false;
            else if (e.KeyCode == Keys.P) p.Visible = false;
            else if (e.KeyCode == Keys.A) a.Visible = false;
            else if (e.KeyCode == Keys.S) s.Visible = false;
            else if (e.KeyCode == Keys.D) d.Visible = false;
            else if (e.KeyCode == Keys.F) f.Visible = false;
            else if (e.KeyCode == Keys.G) g.Visible = false;
            else if (e.KeyCode == Keys.H) h.Visible = false;
            else if (e.KeyCode == Keys.J) j.Visible = false;
            else if (e.KeyCode == Keys.K) k.Visible = false;
            else if (e.KeyCode == Keys.L) l.Visible = false;
            else if (e.KeyCode == Keys.Z) z.Visible = false;
            else if (e.KeyCode == Keys.X) x.Visible = false;
            else if (e.KeyCode == Keys.C) c.Visible = false;
            else if (e.KeyCode == Keys.V) v.Visible = false;
            else if (e.KeyCode == Keys.B) b.Visible = false;
            else if (e.KeyCode == Keys.N) n.Visible = false;
            else if (e.KeyCode == Keys.M) m.Visible = false;
            else if (e.KeyCode == Keys.Back) backspace.Visible = false;
            else if (e.KeyCode == Keys.Enter) newline.Visible = false;
            else if (e.KeyCode == Keys.Space) space.Visible = false;
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text)) lbUsername.Visible = true;
            else lbUsername.Visible = false;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text)) lbPassword.Visible = true;
            else lbPassword.Visible = false;
        }

        private void lbRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var form = new frmRegistration();
            form.Show();
            this.Hide();
            pkeypad.Visible = false;
        }

        private void btnback_default_MouseDown(object sender, MouseEventArgs e)
        {
            btnback.Visible = true;
            btnback_default.Visible = false;
        }

        private void btnback_default_MouseUp(object sender, MouseEventArgs e)
        {
            btnback.Visible = false;
            btnback_default.Visible = true;
            frmMain form = new frmMain();
            form.Show();
            this.Hide();

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            if (!string.IsNullOrEmpty(txtUsername.Text) && !string.IsNullOrEmpty(txtPassword.Text))
            {
                var cust = from a in db.CUSTOMERLOGINs
                           where a.USERNAME == txtUsername.Text && a.PASSWORD == txtPassword.Text
                           select a;
                if (cust.Any())
                {
                    frmProfile prof = new frmProfile();
                    prof.Show();
                    this.Hide();
                }
                else {
                    lbWarning.Visible = true;
                    lbWarning.Text = "*Invalid Username/Password";
                }

            }
            else
            {
                lbWarning.Visible = true;
                lbWarning.Text = "*Please enter your email and password";
            }
            pkeypad.Visible = false;
            
        }

        private void txtUsername_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Q) q.Visible = false;
            else if (e.KeyCode == Keys.W) w.Visible = false;
            else if (e.KeyCode == Keys.E) _e.Visible = false;
            else if (e.KeyCode == Keys.R) r.Visible = false;
            else if (e.KeyCode == Keys.T) t.Visible = false;
            else if (e.KeyCode == Keys.Y) y.Visible = false;
            else if (e.KeyCode == Keys.U) u.Visible = false;
            else if (e.KeyCode == Keys.I) i.Visible = false;
            else if (e.KeyCode == Keys.O) o.Visible = false;
            else if (e.KeyCode == Keys.P) p.Visible = false;
            else if (e.KeyCode == Keys.A) a.Visible = false;
            else if (e.KeyCode == Keys.S) s.Visible = false;
            else if (e.KeyCode == Keys.D) d.Visible = false;
            else if (e.KeyCode == Keys.F) f.Visible = false;
            else if (e.KeyCode == Keys.G) g.Visible = false;
            else if (e.KeyCode == Keys.H) h.Visible = false;
            else if (e.KeyCode == Keys.J) j.Visible = false;
            else if (e.KeyCode == Keys.K) k.Visible = false;
            else if (e.KeyCode == Keys.L) l.Visible = false;
            else if (e.KeyCode == Keys.Z) z.Visible = false;
            else if (e.KeyCode == Keys.X) x.Visible = false;
            else if (e.KeyCode == Keys.C) c.Visible = false;
            else if (e.KeyCode == Keys.V) v.Visible = false;
            else if (e.KeyCode == Keys.B) b.Visible = false;
            else if (e.KeyCode == Keys.N) n.Visible = false;
            else if (e.KeyCode == Keys.M) m.Visible = false;
            else if (e.KeyCode == Keys.Back) backspace.Visible = false;
            else if (e.KeyCode == Keys.Enter) newline.Visible = false;
            else if (e.KeyCode == Keys.Space) space.Visible = false;
        }

        private void btnback_default_Click(object sender, EventArgs e)
        {
            btnback.Visible = false;
            btnback_default.Visible = true;
        }
    }
}
