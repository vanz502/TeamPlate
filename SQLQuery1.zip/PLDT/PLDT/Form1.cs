﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PLDT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBoxUSERNAME.Text != "" && textBoxPASSWORD.Text != "")
            {

                if (Class1.login(textBoxUSERNAME.Text).Count() > 0)
                {
                    if (Class1.login(textBoxUSERNAME.Text)[0].PASSWORD == textBoxPASSWORD.Text)
                    {
                        MessageBox.Show("welcome ADMIN!");
                        Main X = new Main();
                        X.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Password!");
                    }
                }
                else
                {
                    MessageBox.Show("Account Not Found!");
                }

            }
            else
            {
                MessageBox.Show("Fill in the empty fields");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBoxUSERNAME_TextChanged(object sender, EventArgs e)
        {
            if (textBoxUSERNAME.Text == "")
            {
                lblUsername.Visible = true;
            }
            else {
                lblUsername.Visible = false;
            }
        }

        private void textBoxPASSWORD_TextChanged(object sender, EventArgs e)
        {
            if (textBoxPASSWORD.Text == "")
            {
                lblPassword.Visible = true;
            }
            else
            {
                lblPassword.Visible = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBoxPASSWORD_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
    }
}
