﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PLDT
{
    public partial class Account : Form
    {
        public Account()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Account_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Class1.ReserveDisplay();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Message has been sent!");
        }
    }
}
