﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PLDT
{
    public partial class Queue : Form
    {
        public Queue()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void Main_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("hh:mm:ss tt");
            timer1.Enabled = true;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clear();
        }
        void Clear()
        {
            textBox1.Clear();
            textBox2.Clear();
            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Message has been sent!");
            Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Calling Jovan...","Calling...",MessageBoxButtons.OKCancel,MessageBoxIcon.Hand);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
