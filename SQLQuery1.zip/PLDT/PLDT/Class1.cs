﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PLDT
{
    public class Class1
    {
        static DataClasses1DataContext db = null;

        public static List<SP_LOGINResult> login(string key)
        {
            db = new DataClasses1DataContext();
            List<SP_LOGINResult> list = db.SP_LOGIN(key).ToList<SP_LOGINResult>();
            return list;
        }

        public static List<SP_QUEUEResult> displayQUEUE()
        {
            db = new DataClasses1DataContext();
            List<SP_QUEUEResult> list = db.SP_QUEUE().ToList<SP_QUEUEResult>();
            return list;
        }
        public static List<View_AccResult> AccountDisplay()
        {
            db = new DataClasses1DataContext();
            List<View_AccResult> list = db.View_Acc().ToList<View_AccResult>();
            return list;
        }
        public static List<View_InfoResult> InfoDisplay()
        {
            db = new DataClasses1DataContext();
            List<View_InfoResult> list = db.View_Info().ToList<View_InfoResult>();
            return list;
        }
        public static List<View_ReserveDetailsResult> ReserveDisplay()
        {
            db = new DataClasses1DataContext();
            List<View_ReserveDetailsResult> list = db.View_ReserveDetails().ToList<View_ReserveDetailsResult>();
            return list;
        }
    }
}
